#pragma once
#include <string>
#include <iostream>
#include "User.hpp"

// Linked list node to hold user information
struct UserNode {
    User user;
    UserNode* next;

    UserNode(const std::string& username, const std::string& password, Role role)
        : user(username, password, role), next(nullptr) {}
};

class UserManager {
private:
    UserNode* head;
    User* loggedInUser;

public:
    UserManager() : head(nullptr), loggedInUser(nullptr) {}

    // Method to add a user
    void addUser(const std::string& username, const std::string& password, Role role) {
        UserNode* newNode = new UserNode(username, password, role);
        newNode->next = head;
        head = newNode;
    }

    // Method to login
    bool login(const std::string& username, const std::string& password) {
        UserNode* current = head;
        while (current != nullptr) {
            if (current->user.getUsername() == username && current->user.authenticate(password)) {
                loggedInUser = &current->user;
                std::cout << "Login successful!\n";
                return true;
            }
            current = current->next;
        }
        std::cout << "Invalid username or password.\n";
        return false;
    }

    // Method to check if a user is logged in
    bool isLoggedIn() const {
        return loggedInUser != nullptr;
    }

    // Getter for the logged-in user
    User* getLoggedInUser() const {
        return loggedInUser;
    }

    // Destructor to free memory
    ~UserManager() {
        while (head != nullptr) {
            UserNode* temp = head;
            head = head->next;
            delete temp;
        }
    }
};
