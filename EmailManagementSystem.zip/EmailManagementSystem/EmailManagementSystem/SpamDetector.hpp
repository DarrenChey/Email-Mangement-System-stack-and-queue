#pragma once
#include "QueueLinkedList.hpp"
#include "UserManager.hpp"  // Include UserManager for role-based functionality
#include "Inbox.hpp"  // Include Inbox to allow removing from inbox

class SpamDetector {
private:
    QueueLinkedList spamQueue;

public:
    // Method to mark an email as spam by enqueueing it into the spam queue
    void markSpam(UserManager& userManager, Inbox& inbox, const std::string& email) {
        // Check if the user is logged in (for now, assuming both admin and user can mark spam)
        if (userManager.isLoggedIn()) {
            // First, try to delete the email from the inbox
            inbox.deleteEmail(email);

            // Then enqueue the email in the spam queue
            spamQueue.enqueue(email);
            std::cout << "Email marked as spam: " << email << std::endl;
        }
        else {
            std::cout << "You do not have permission to mark emails as spam.\n";
        }
    }


    // Method to display spam emails (both admin and user roles can view spam)
    void showSpam() const {
        if (spamQueue.isEmpty()) {
            std::cout << "No spam emails. (Queue is empty)\n";  // Add debug output
        }
        else {
            std::cout << "Displaying spam emails:\n";
            spamQueue.displayQueue();
        }
    }

    // Method to mark an email manually as spam by enqueueing it into the spam queue
    void markSpamManually(UserManager& userManager, Inbox& inbox, const std::string& email) {
        // Check if the user is logged in (for now, assuming both admin and user can mark spam)
        if (userManager.isLoggedIn()) {
            // First, find the email in the inbox and delete it based on the sender's email address
            bool emailFound = false;
            StackLinkedList tempStack;

            // Pop all emails until we find the one to delete
            while (!inbox.isEmpty()) {  // Use inbox's method to check if the inbox is empty
                std::string currentEmail = inbox.peek();  // Use inbox's method to peek at the top email
                inbox.pop();  // Use inbox's method to pop the top email

                // Extract the sender (assuming "From:" is at the start)
                size_t senderPos = currentEmail.find("From: ");
                if (senderPos != std::string::npos) {
                    senderPos += 6;  // Skip the "From: " part
                    size_t endPos = currentEmail.find(",", senderPos);
                    std::string sender = currentEmail.substr(senderPos, endPos - senderPos);

                    // Check if the extracted sender matches the spam email
                    if (sender == email) {
                        emailFound = true;
                        spamQueue.enqueue(currentEmail);  // Enqueue the full email content
                        std::cout << "Email marked as spam: " << currentEmail << std::endl;
                        break;
                    }
                }

                // Keep email in temp stack
                tempStack.push(currentEmail);
            }

            // Push all emails back to the inbox stack
            while (!tempStack.isEmpty()) {
                inbox.push(tempStack.peek());  // Use inbox's method to push the email back
                tempStack.pop();
            }

            if (!emailFound) {
                std::cout << "Email not found in inbox.\n";
            }
        }
        else {
            std::cout << "You do not have permission to mark emails as spam.\n";
        }
    }
};
